﻿//Start
    document.querySelectorAll('.mtd-config-param').forEach((surface) => {
        const ripple = new mdc.ripple.MDCRipple(surface);
    });        
