﻿//const rippleFor = (className) => {
//    const ripples = document.querySelectorAll(className);
//    ripples.forEach((obj) => {
//        const ripple = new mdc.ripple.MDCRipple(obj);
//        ripple.unbounded = true;
//    });
//    return true;
//}



//Start
    //const textFields = document.querySelectorAll('.mdc-text-field');
    //textFields.forEach((item) => {
    //    const textField = new mdc.textField.MDCTextField(item);        
    //    const fond = new mdc.textField.MDCTextFieldFoundation(textField);    
    //});

    //rippleFor('.mdc-checkbox');
    //rippleFor('.mdc-icon-button');
    //rippleFor('.mdc-list-item');
    //rippleFor('.mdc-fab');
    //rippleFor('.mdc-button');
    //rippleFor('.mdc-card__primary-action');